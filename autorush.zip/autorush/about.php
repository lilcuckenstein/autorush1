<?php
require_once 'config.php';
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rólunk | AutoRush</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php include 'includes/navbar.php'; ?>
    
    <main class="container my-5">
        <div class="row">
            <div class="col-lg-6">
                <h1 class="mb-4">Rólunk</h1>
                <p class="lead">Az AutoRush egy vezető autóbérlő szolgáltatás, amely 2010 óta biztosítja ügyfeleink számára a legjobb autóbérlési élményt.</p>
                
                <h2 class="mt-5">Célunk</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in dui mauris. Vivamus hendrerit arcu sed erat molestie vehicula.</p>
                
                <h2 class="mt-5">Flottánk</h2>
                <p>Széles választékban kínálunk járműveket, a kompakt autóktól a luxus limuzinokig, mindig a legújabb modellekből.</p>
            </div>
            
            <div class="col-lg-6">
                <img src="assets/images/about.jpg" class="img-fluid rounded shadow" alt="Rólunk kép">
            </div>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>