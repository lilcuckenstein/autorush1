<?php
class CarManager {
    private $db;
    
    public function __construct($db) {
        $this->db = $db;
    }
    
    public function getFeaturedCars() {
        $stmt = $this->db->prepare("
            SELECT c.*, b.name as brand_name 
            FROM cars c 
            JOIN brands b ON c.brand_id = b.id 
            ORDER BY RAND() 
            LIMIT 3
        ");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getCars($filters = []) {
        $query = "SELECT c.*, b.name as brand_name FROM cars c JOIN brands b ON c.brand_id = b.id WHERE 1=1";
        $params = [];
        
        if(!empty($filters['type'])) {
            $query .= " AND c.type = ?";
            $params[] = $filters['type'];
        }
        
        if(!empty($filters['price'])) {
            $priceRange = explode('-', $filters['price']);
            if(count($priceRange) === 2) {
                $query .= " AND c.price_per_day BETWEEN ? AND ?";
                $params[] = $priceRange[0];
                $params[] = $priceRange[1];
            }
        }
        
        $query .= " ORDER BY c.price_per_day ASC";
        $stmt = $this->db->prepare($query);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getCarDetails($carId) {
        $stmt = $this->db->prepare("
            SELECT c.*, b.name as brand_name 
            FROM cars c 
            JOIN brands b ON c.brand_id = b.id 
            WHERE c.id = ?
        ");
        $stmt->execute([$carId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
?>