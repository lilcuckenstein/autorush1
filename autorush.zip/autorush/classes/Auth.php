<?php
class Auth {
    private $db;
    
    public function __construct($db) {
        $this->db = $db;
    }
    
    public function register($userData) {
        $errors = [];
        
        // Validációk
        if(empty($userData['name'])) {
            $errors[] = "A név megadása kötelező";
        }
        
        if(empty($userData['email'])) {
            $errors[] = "Az email megadása kötelező";
        } elseif(!filter_var($userData['email'], FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Érvénytelen email formátum";
        } else {
            $stmt = $this->db->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$userData['email']]);
            if($stmt->rowCount() > 0) {
                $errors[] = "Ez az email cím már regisztrálva van";
            }
        }
        
        if(empty($userData['password'])) {
            $errors[] = "A jelszó megadása kötelező";
        } elseif(strlen($userData['password']) < 8) {
            $errors[] = "A jelszónak legalább 8 karakter hosszúnak kell lennie";
        } elseif($userData['password'] !== $userData['confirm_password']) {
            $errors[] = "A jelszavak nem egyeznek";
        }
        
        if(empty($userData['phone'])) {
            $errors[] = "A telefonszám megadása kötelező";
        }
        
        if(empty($userData['license'])) {
            $errors[] = "A jogosítványszám megadása kötelező";
        }
        
        if(count($errors) === 0) {
            $hashedPassword = password_hash($userData['password'], PASSWORD_BCRYPT);
            
            $stmt = $this->db->prepare("INSERT INTO users (name, email, password, phone, driver_license) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([
                $userData['name'],
                $userData['email'],
                $hashedPassword,
                $userData['phone'],
                $userData['license']
            ]);
            
            return true;
        }
        
        return $errors;
    }
    
    public function login($email, $password) {
        $stmt = $this->db->prepare("SELECT id, password FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            return true;
        }
        
        return false;
    }
    
    public function getUser($userId) {
        $stmt = $this->db->prepare("SELECT id, name, email, phone, driver_license FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
?>