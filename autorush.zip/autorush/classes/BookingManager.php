<?php
class BookingManager {
    private $db;
    
    public function __construct($db) {
        $this->db = $db;
    }
    
    public function createBooking($bookingData) {
        $errors = [];
        
        // Dátum validáció
        $startDate = new DateTime($bookingData['start_date']);
        $endDate = new DateTime($bookingData['end_date']);
        
        if($startDate > $endDate) {
            $errors[] = "A visszahozatal dátuma nem lehet korábbi, mint az átvétel dátuma";
        }
        
        // Elérhetőség ellenőrzése
        if(!$this->checkAvailability($bookingData['car_id'], $bookingData['start_date'], $bookingData['end_date'])) {
            $errors[] = "A választott autó nem elérhető a megadott időszakban";
        }
        
        if(count($errors) === 0) {
            // Ár kalkuláció
            $car = $this->getCarPrice($bookingData['car_id']);
            $days = $startDate->diff($endDate)->days + 1;
            $totalPrice = $days * $car['price_per_day'];
            
            try {
                $stmt = $this->db->prepare("
                    INSERT INTO bookings 
                    (user_id, car_id, start_date, end_date, total_price, status) 
                    VALUES (?, ?, ?, ?, ?, 'pending')
                ");
                $stmt->execute([
                    $bookingData['user_id'],
                    $bookingData['car_id'],
                    $bookingData['start_date'],
                    $bookingData['end_date'],
                    $totalPrice
                ]);
                
                return true;
            } catch(PDOException $e) {
                $errors[] = "Adatbázis hiba: " . $e->getMessage();
            }
        }
        
        return $errors;
    }
    
    public function checkAvailability($carId, $startDate, $endDate) {
        $stmt = $this->db->prepare("
            SELECT COUNT(*) as count 
            FROM bookings 
            WHERE car_id = ? 
            AND status IN ('pending', 'confirmed')
            AND (
                (start_date BETWEEN ? AND ?)
                OR (end_date BETWEEN ? AND ?)
                OR (? BETWEEN start_date AND end_date)
                OR (? BETWEEN start_date AND end_date)
            )
        ");
        $stmt->execute([$carId, $startDate, $endDate, $startDate, $endDate, $startDate, $endDate]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $result['count'] == 0;
    }
    
    public function getUserBookings($userId) {
        $stmt = $this->db->prepare("
            SELECT b.*, c.model, c.brand_id, br.name as brand_name 
            FROM bookings b
            JOIN cars c ON b.car_id = c.id
            JOIN brands br ON c.brand_id = br.id
            WHERE b.user_id = ?
            ORDER BY b.start_date DESC
        ");
        $stmt->execute([$userId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function cancelBooking($bookingId, $userId) {
        $stmt = $this->db->prepare("
            UPDATE bookings 
            SET status = 'cancelled' 
            WHERE id = ? AND user_id = ? AND status = 'pending'
        ");
        return $stmt->execute([$bookingId, $userId]);
    }
    
    private function getCarPrice($carId) {
        $stmt = $this->db->prepare("SELECT price_per_day FROM cars WHERE id = ?");
        $stmt->execute([$carId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
?>