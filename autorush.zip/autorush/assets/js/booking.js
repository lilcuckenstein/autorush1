// Foglalási dátum kalkuláció
document.addEventListener('DOMContentLoaded', function() {
    const pickupDate = document.getElementById('start_date');
    const returnDate = document.getElementById('end_date');
    const pricePerDay = parseFloat(document.getElementById('price_per_day').value);
    const totalPriceElement = document.getElementById('total-price');
    
    function calculatePrice() {
        const pickup = new Date(pickupDate.value);
        const returnD = new Date(returnDate.value);
        
        if(pickup && returnD && returnD > pickup) {
            const days = Math.ceil((returnD - pickup) / (1000 * 60 * 60 * 24));
            const total = days * pricePerDay;
            
            totalPriceElement.innerHTML = `
                ${days} nap × ${pricePerDay.toLocaleString()} Ft = 
                <strong>${total.toLocaleString()} Ft</strong>
            `;
            totalPriceElement.classList.remove('alert-info');
            totalPriceElement.classList.add('alert-success');
        } else {
            totalPriceElement.innerHTML = 'Válassza ki a dátumokat az ár kiszámolásához';
            totalPriceElement.classList.remove('alert-success');
            totalPriceElement.classList.add('alert-info');
        }
    }
    
    if(pickupDate && returnDate) {
        pickupDate.addEventListener('change', function() {
            returnDate.min = this.value;
            calculatePrice();
        });
        
        returnDate.addEventListener('change', calculatePrice);
    }
});