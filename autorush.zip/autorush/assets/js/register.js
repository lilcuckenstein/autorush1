// Regisztrációs űrlap validáció
document.addEventListener('DOMContentLoaded', function() {
    const registerForm = document.getElementById('register-form');
    if(registerForm) {
        registerForm.addEventListener('submit', function(e) {
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if(password !== confirmPassword) {
                e.preventDefault();
                alert('A jelszavak nem egyeznek!');
            }
        });
    }
});