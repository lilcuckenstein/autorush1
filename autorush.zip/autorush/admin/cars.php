<?php
require_once 'config.php';
require_once '../../classes/CarManager.php';

$carManager = new CarManager($db);

// Jármű törlése
if(isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $carId = (int)$_GET['delete'];
    try {
        $stmt = $db->prepare("DELETE FROM cars WHERE id = ?");
        $stmt->execute([$carId]);
        $_SESSION['admin_message'] = ['type' => 'success', 'text' => 'Jármű sikeresen törölve!'];
    } catch(PDOException $e) {
        $_SESSION['admin_message'] = ['type' => 'danger', 'text' => 'Hiba történt a törlés során!'];
    }
    header("Location: cars.php");
    exit;
}

// Járművek listázása
$cars = $carManager->getCars();
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Járművek Kezelése | AutoRush</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
</head>
<body>
    <?php include 'includes/admin_sidebar.php'; ?>

    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Járművek Kezelése</h1>
            <div class="btn-toolbar mb-2 mb-md-0">
                <a href="car_add.php" class="btn btn-sm btn-outline-primary">
                    <i class="bi bi-plus-circle"></i> Új jármű
                </a>
            </div>
        </div>

        <?php if(isset($_SESSION['admin_message'])): ?>
            <div class="alert alert-<?php echo $_SESSION['admin_message']['type']; ?>">
                <?php echo $_SESSION['admin_message']['text']; ?>
            </div>
            <?php unset($_SESSION['admin_message']); ?>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Kép</th>
                                <th>Márka</th>
                                <th>Modell</th>
                                <th>Ár/nap</th>
                                <th>Státusz</th>
                                <th>Műveletek</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($cars as $car): ?>
                            <tr>
                                <td><?php echo $car['id']; ?></td>
                                <td>
                                    <img src="../../assets/images/<?php echo $car['image']; ?>" width="50" height="30" class="img-thumbnail">
                                </td>
                                <td><?php echo $car['brand_name']; ?></td>
                                <td><?php echo $car['model']; ?></td>
                                <td><?php echo number_format($car['price_per_day'], 0, ',', ' '); ?> Ft</td>
                                <td>
                                    <span class="badge bg-<?php echo $car['available'] ? 'success' : 'danger'; ?>">
                                        <?php echo $car['available'] ? 'Elérhető' : 'Nem elérhető'; ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="car_edit.php?id=<?php echo $car['id']; ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <a href="cars.php?delete=<?php echo $car['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Biztosan törölni szeretnéd ezt a járművet?')">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>