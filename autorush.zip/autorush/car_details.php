<?php
require_once 'config.php';
require_once 'classes/CarManager.php';
require_once 'classes/BookingManager.php';

if(!isset($_GET['id']) || empty($_GET['id'])) {
    redirect('cars.php');
}

$carManager = new CarManager($db);
$bookingManager = new BookingManager($db);

$carId = (int)$_GET['id'];
$car = $carManager->getCarDetails($carId);

if(!$car) {
    redirect('cars.php');
}

// Foglalás feldolgozása
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_SESSION['user_id'])) {
    $bookingData = [
        'user_id' => $_SESSION['user_id'],
        'car_id' => $carId,
        'start_date' => $_POST['start_date'],
        'end_date' => $_POST['end_date']
    ];
    
    $result = $bookingManager->createBooking($bookingData);
    
    if($result === true) {
        $_SESSION['booking_success'] = true;
        redirect('profile.php');
    } else {
        $error = implode('<br>', $result);
    }
}

// Elérhetőség ellenőrzése
$available = true;
if(isset($_GET['start_date']) && isset($_GET['end_date'])) {
    $available = $bookingManager->checkAvailability($carId, $_GET['start_date'], $_GET['end_date']);
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $car['brand_name'].' '.$car['model']; ?> | AutoRush</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php include 'includes/navbar.php'; ?>
    
    <main class="container my-5">
        <div class="row">
            <div class="col-md-6">
                <img src="assets/images/<?php echo $car['image']; ?>" class="img-fluid rounded mb-3" alt="<?php echo $car['brand_name'].' '.$car['model']; ?>">
                
                <div class="card mb-3">
                    <div class="card-header">
                        <h3>Jármű adatai</h3>
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Márka</span>
                                <span><?php echo $car['brand_name']; ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Modell</span>
                                <span><?php echo $car['model']; ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Évjárat</span>
                                <span><?php echo $car['year']; ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Típus</span>
                                <span><?php echo $car['type']; ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Ülések száma</span>
                                <span><?php echo $car['seats']; ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Ár/nap</span>
                                <span class="fw-bold"><?php echo number_format($car['price_per_day'], 0, ',', ' '); ?> Ft</span>
                            </li>
                        </ul>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header">
                        <h3>Leírás</h3>
                    </div>
                    <div class="card-body">
                        <p><?php echo $car['description'] ?: 'Ehhez a járműhöz még nem érkezett leírás.'; ?></p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="card sticky-top" style="top: 20px;">
                    <div class="card-header">
                        <h3>Foglalás</h3>
                    </div>
                    <div class="card-body">
                        <?php if(isset($error)): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <?php if(!isset($_SESSION['user_id'])): ?>
                            <div class="alert alert-warning">
                                A foglaláshoz be kell jelentkeznie. <a href="login.php" class="alert-link">Bejelentkezés</a> vagy <a href="register.php" class="alert-link">regisztráció</a>.
                            </div>
                        <?php else: ?>
                            <form method="post" action="car_details.php?id=<?php echo $carId; ?>">
                                <input type="hidden" name="car_id" value="<?php echo $carId; ?>">
                                
                                <div class="mb-3">
                                    <label for="start_date" class="form-label">Átvétel dátuma</label>
                                    <input type="date" class="form-control" id="start_date" name="start_date" min="<?php echo date('Y-m-d'); ?>" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="end_date" class="form-label">Visszahozatal dátuma</label>
                                    <input type="date" class="form-control" id="end_date" name="end_date" min="<?php echo date('Y-m-d'); ?>" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Összesen</label>
                                    <div class="alert alert-info" id="total-price">
                                        Válassza ki a dátumokat az ár kiszámolásához
                                    </div>
                                </div>
                                
                                <button type="submit" class="btn btn-primary w-100 py-2">Foglalás</button>
                            </form>
                            
                            <input type="hidden" id="price_per_day" value="<?php echo $car['price_per_day']; ?>">
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/booking.js"></script>
</body>
</html>