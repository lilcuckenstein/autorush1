<?php
require_once '../config.php';
require_once '../classes/CarManager.php';

header('Content-Type: application/json');

$carManager = new CarManager($db);
$filters = [];

if(isset($_GET['type']) && !empty($_GET['type'])) {
    $filters['type'] = sanitizeInput($_GET['type']);
}

if(isset($_GET['price']) && !empty($_GET['price'])) {
    $filters['price'] = sanitizeInput($_GET['price']);
}

$cars = $carManager->getCars($filters);
echo json_encode($cars);
?>