<?php
require_once '../config.php';

header('Content-Type: application/json');

if(!isset($_GET['email'])) {
    echo json_encode(['exists' => false]);
    exit;
}

$email = sanitizeInput($_GET['email']);
$stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
$stmt->execute([$email]);

echo json_encode(['exists' => $stmt->rowCount() > 0]);
?>